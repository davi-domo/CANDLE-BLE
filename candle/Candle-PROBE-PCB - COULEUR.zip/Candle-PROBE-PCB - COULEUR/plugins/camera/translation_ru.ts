<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>frmMain</name>
    <message>
        <source>Camera</source>
        <translation>Камера</translation>
    </message>   
    </context>
    <context>
    <name>pluginCameraSettings</name>
    <message>
        <source>Name:</source>
        <translation>Наименование:</translation>
    </message>          
    <message>
        <source>Resolution:</source>
        <translation>Разрешение:</translation>
    </message>          
    <message>
        <source>Position:</source>
        <translation>Позиция:</translation>
    </message>          
    <message>
        <source>Zoom:</source>
        <translation>Масштаб:</translation>
    </message>          
    <message>
        <source>Aim position:</source>
        <translation>Позиция перекрестия:</translation>
    </message>          
    <message>
        <source>Aim size:</source>
        <translation>Размер перекрестия:</translation>
    </message>          
    <message>
        <source>Aim line width:</source>
        <translation>Толщина линии:</translation>
    </message>          
    <message>
        <source>Aim color:</source>
        <translation>Цвет перекрестия:</translation>
    </message>          
</context>
</TS>