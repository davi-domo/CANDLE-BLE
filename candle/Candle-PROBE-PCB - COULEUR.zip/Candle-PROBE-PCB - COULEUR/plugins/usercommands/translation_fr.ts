<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <message>
        <source>User button</source>
        <translation>bouton utilisateur</translation>
    </message>   
    <name>frmMain</name>
    <message>
        <source>User commands</source>
        <translation>commande utilisateur</translation>
    </message>   
    </context>
    <context>
    <name>UserCommandsSettings</name>
    <message>
        <source>Hint</source>
        <translation>Nom</translation>
    </message>   
    <message>
        <source>Icon</source>
        <translation>Icone</translation>
    </message> 
    <message>
        <source>G-code</source>
        <translation>G-code</translation>
    </message> 
    <message>
        <source>Up</source>
        <translation>Monter</translation>
    </message> 
    <message>
        <source>Descendre</source>
        <translation>Вниз</translation>
    </message> 
    <message>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message> 
    <message>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message> 
    <message>
        <source>Remove all</source>
        <translation>Supprimer tout</translation>
    </message> 
</context>
</TS>